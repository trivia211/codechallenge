function setup() {
    createCanvas()
    resizeCanvas(800, 600)
}

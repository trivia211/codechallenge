createCanvas()
resizeCanvas(800, 600)

function update() {

}

function draw() {

}
